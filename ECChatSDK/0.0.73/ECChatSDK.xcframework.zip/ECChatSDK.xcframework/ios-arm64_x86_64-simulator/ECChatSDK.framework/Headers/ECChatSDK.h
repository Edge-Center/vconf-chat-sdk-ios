//
//  ECChatSDK.h
//  ECChatSDK
//
//  Created by Maxim Myakishev on 6.06.2023.
//

#import <Foundation/Foundation.h>

//! Project version number for ECChatSDK.
FOUNDATION_EXPORT double ECChatSDKVersionNumber;

//! Project version string for ECChatSDK.
FOUNDATION_EXPORT const unsigned char ECChatSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ECChatSDK/PublicHeader.h>


